# Full Safe IAD source-code bundle

This ZIP contains the complete current framework code, configuration plans,
unit/contract tests, data acquisition/verification utilities, installers,
documentation, official dependency source snapshots and license notices.
It also includes actual pilot metrics, plots, verification and reproduction
reports. The code is the strict normal-calibration implementation tested in
the cloud environment; all 44 tests passed.

Layout:
- tools/: the installable safe_iad package, scripts, configs and tests.
- vendor/: pinned official DINOv2, AnomalyDINO, SubspaceAD and MVTec AD 2
  utility source snapshots and their original licenses.
- reports/: actual measured results and manifests, not generated mock results.
- BUNDLED_DEPENDENCIES.json: upstream revisions and provenance.
- MANIFEST.sha256.json: SHA256 for every bundled file except this manifest.

Datasets, pretrained checkpoint binaries, virtual environments, feature caches,
large per-image prediction arrays and Git metadata are intentionally separate
from this source-code download. They are required for a new real-data run.
No credentials or environment secrets are included.

The audited configuration targets absolute /workspace paths. In the existing
cloud environment, run:

    bash /workspace/tools/install_runtime.sh
    cd /workspace/tools
    source /workspace/venvs/safe_iad/bin/activate
    python -m safe_iad.run_pipeline --config configs/experiment_plan.yaml --reproduce true

For another environment, place the package/data/reports at the documented
/workspace locations or adapt those paths with a new output directory.
The installer clones pinned upstream Git dependencies. The vendor snapshots
are provided as full source for inspection; they omit Git metadata and cannot
be substituted unchanged where the runtime verifies Git HEAD.
Read tools/README.md for dataset/checkpoint locations and baseline variants.
Data acquisition source URLs and archive checksums are included in reports.
The pretrained-weight verifier and data-verification modules fail on missing
or invalid inputs; they never substitute random weights or fake benchmarks.

The default is a completed feasibility pilot. It is not validated production
inspection, and full published benchmark recipes/private AD 2 evaluation have
not been run. The empirical adequacy rule does not provide reliable decisions
in this pilot. Read reports/hybrid_framework_report.md before interpreting
results. No novelty, SOTA, calibrated-probability or theoretical reliability
claim is made.
