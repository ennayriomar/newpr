# Trained SAFAL — 14 October 2026

SAFAL is a computer-vision anomaly model. This run fitted normal PCA/reference banks and learned an image-error estimation head. The actual pretrained DINOv2 encoder remained frozen; no LLM or foundation-backbone fine-tuning was performed.

Start with reports/verification/analysis/report.md and its measured tables/plots. The wider run contains 320 source fitting examples from 160 normal parents,80 heldout source examples from 40 separate parents, and100 unique real development-validation images across 5 categories. Four support counts and 3 draws yield 60 target fits,1,200 paired inspections and 6,000 five-method records. Native labels were accessed after prediction only. The source error head used normal/CutPaste proxy events; native and cross-shot probability transfer are unverified.

Five predeclared k4/seed17 normal-bank models (one per category) are in models/, together with the trained error_calibrator.json. These examples were chosen by fixed support count and first draw, not performance. All 70 source/target fitted banks,60 replay probes and 1,200 metric-map files are in the separately published complete result archive. The measured report states actual outcomes without guaranteeing improved accuracy or deployment reliability. Eighteen current validation images appeared in the five audited earlier runs; this is development validation, not pristine final evaluation.

```bash
cd tools
bash install_safal.sh
source .venv/bin/activate
python -m safe_iad.safal_cli prepare --destination ../safal_assets
```

Edit the selected models/<episode>/encoder.json runtime_config paths to the prepared source/checkpoint and a writable cache. Preserve the verified checkpoint/source hashes, block/layer settings and preprocessing. Predict on a real image:

```bash
python -m safe_iad.safal_cli predict --model ../models/mvtec_ad-hazelnut-k4-seed17/model --image YOUR_IMAGE.png --encoder-config ../models/mvtec_ad-hazelnut-k4-seed17/encoder.json --error-calibrator ../models/error_calibrator.json --output ./prediction
```

The pipeline exports native prediction maps; evaluation used declared 256x256 metric maps. See tools/docs/full_model.md for equations/CLI semantics and tools/configs/safal_training_20261014.json for this exact wider protocol. Set local dataset paths and a fresh output directory to reproduce training. The complete result downloader is tools/download_safal_training_results.py. Raw dataset/generated images, feature caches and pretrained backbone binaries are excluded; models require the separate verified backbone. Copied completion ledgers retain original input paths and do not establish a new local resume.

MANIFEST.sha256.json verifies every bundled file except itself. Read MODEL_ARTIFACT_NOTICE.md and vendor licenses before reusing dataset-derived banks.
