# Safe IAD full source bundle, v0.4.0

This bundle contains the research framework, its configuration plans, tests,
data verification and acquisition helpers, pinned official dependency source
snapshots, licenses and saved research reports. The GitHub repository is
https://github.com/ennayriomar/newpr. Its executable package is under
`framework/`; the source ZIP places the same package under `tools/`.

The supported runtime is Linux with Python 3.12 and the pinned CPU PyTorch
runtime. CUDA and other Python versions have not been validated. This is research
software; full benchmark reproduction and reliable production inspection are
not established. Read the measured milestone reports before interpreting the
methods or advancing to larger experiments.

The current M3 feasibility gate failed. Learned acquisition increased declared
mean benefit but introduced four correlated newly missed defect inspection
records at locked cutoffs and reduced defect-pixel recall; matched omission
controls did not establish a consistent missing-support false-alarm effect.
Full learned-acquisition experiments were stopped, with no post-outcome tuning.
All 97 unit/contract tests passed. The separate artifact audit verified 39 stage
ledgers, 1,903 unique output files and 547 unique inputs across 576 records/20
unique query images. Two cache-bypassed real-query probes matched saved features,
selections, scores and maps. These checks do not constitute a full independent
rerun or production-reliability evidence. Read the M3 `research_report.md`,
`validation.json`, `real_weight_reproduction.json` and `evaluation/gate.json`.

## Contents and scope

- `tools/`: installable `safe_iad` package, configs, tests, CLI tools and installer.
- `vendor/`: official source snapshots and original licenses.
- `reports/`: saved measured summaries, provenance and figures for inspection.
- `BUNDLED_DEPENDENCIES.json`: upstream source revisions and snapshot metadata.
- `MANIFEST.sha256.json`: hashes for bundled files, except the manifest itself.

Raw datasets, pretrained checkpoint binaries, virtual environments, dependency
wheels, feature caches and large native-resolution prediction arrays are
separate downloads. A source ZIP alone cannot run the real-data experiments.
The previously uploaded complete results archive remains separate.

## Restore the documented cloud layout

The current audited source uses absolute `/workspace` paths. On a fresh Linux
environment, place the extracted ZIP's `tools/` directory at `/workspace/tools`.
When using the GitHub source checkout, place `framework/` there instead. Preserve
any existing tools, data and result directories; do not overwrite them with a
different bundle. This release does not claim a portable arbitrary-path install
or an independently validated fresh-environment restoration.

Required locations:

| Input | Location |
| --- | --- |
| Framework | `/workspace/tools` |
| MVTec AD, native category layout | `/workspace/datasets/mvtec_ad` |
| VisA, native image layout and `split_csv/1cls.csv` | `/workspace/datasets/visa` |
| MVTec AD 2 retained public data | `/workspace/datasets/mvtec_ad2_public/mvtec_ad_2` |
| Official AD 2 utility source | `/workspace/datasets/official_ad2_tools/MVTecAD2_public_code_utils` |
| Official DINOv2 Git checkout | `/workspace/.cache/dinov2-source` |
| Official AnomalyDINO Git checkout | `/workspace/.cache/anomalydino-source` |
| Official SubspaceAD Git checkout | `/workspace/.cache/subspacead-source` |
| Official ViT-B/14 checkpoint | `/workspace/.cache/torch/hub/checkpoints/dinov2_vitb14_pretrain.pth` |
| Fresh weight-verification report | `/workspace/reports/real_weight_verification.json` |

The original online dataset sources and archive checksums are recorded in
`reports/dataset_downloads/download_manifest.json`. The data acquisition helper
is `tools/acquire_public_data.py`; it requires an explicit official archive URL
or local archive, SHA256, output root and report path. It stages extraction and
refuses to overwrite an existing root. Read its `--help` before downloading.
The retained AD 2 data includes training, validation and public-test images;
private-test images and server results are absent. Restoring all retained data
requires substantially more storage than the source bundle. Acquisition of the
public AD 2 subset still reads the complete compressed archive to verify it.

On a fresh layout, copy the bundled official AD 2 utility directory from
`vendor/mvtec_ad2_official_utils/` to the utility location in the table. Preserve
`license.txt`, `README.txt`, `utils.py` and the remaining original utility files.
Its bundled source is needed even for local public-map export checks.

## Install dependencies and verify real inputs

Use Python 3.12 as `python3`, then run:

```bash
python3 --version
bash /workspace/tools/install_runtime.sh
source /workspace/venvs/safe_iad/bin/activate
cd /workspace/tools
python -m unittest discover -s tests -v
```

The installer pins runtime dependencies and installs the package in editable
mode. `pip install -e tools` alone does not install those dependencies. It also
clones the official source repositories at these exact revisions:

| Dependency | Source | Git revision |
| --- | --- | --- |
| DINOv2 | https://github.com/facebookresearch/dinov2 | `7764ea0f912e53c92e82eb78a2a1631e92725fc8` |
| AnomalyDINO | https://github.com/dammsi/AnomalyDINO | `b9d1c2648e3a5247437d4d953d907a8f3d994457` |
| SubspaceAD | https://github.com/CLendering/SubspaceAD | `ef56d5c8ab2f1feb7dda1c93b25cc3f73f0960d7` |

These dependencies retain their original Apache-2.0 licenses and notices;
DINOv2's additional bundled third-party notices also remain present. The vendor
snapshots support inspection and attribution. They omit Git metadata and must
not be copied unchanged into cache locations where runtime verifies Git HEAD.
Network access is required for the installer and an uncached official checkpoint.
Dataset permissions are separate: MVTec datasets use CC BY-NC-SA 4.0 and VisA
uses CC BY 4.0. This research setup does not establish commercial deployment.

After obtaining and restoring the real datasets, verify them:

```bash
python -m safe_iad.verify_dataset --dataset mvtec_ad --root /workspace/datasets/mvtec_ad --output /workspace/reports/dataset_verification --workers 4
python -m safe_iad.verify_dataset --dataset visa --root /workspace/datasets/visa --output /workspace/reports/dataset_verification --workers 4
python -m safe_iad.verify_dataset --dataset mvtec_ad2 --root /workspace/datasets/mvtec_ad2_public/mvtec_ad_2 --output /workspace/reports/dataset_verification --workers 4
python verify_dinov2.py --image /workspace/datasets/visa/candle/Data/Images/Normal/0000.JPG --report /workspace/reports/real_weight_verification.json
```

The weight probe uses the official HTTPS loader to obtain the actual pretrained
DINOv2 ViT-B/14 checkpoint. It strictly loads the model, freezes it, checks a real
image's patch grid and repeated CPU extraction, and records checkpoint/source
provenance. Failure stops execution; random weights are never substituted.
Generate this report for the restored inputs instead of treating a copied report
as verification of a fresh installation.

## Run the milestone pilots

These commands use the declared configurations. Do not tune settings from locked
final-test or offline-oracle outcomes. Use new output directories for new runs.

Milestone 1: frozen-feature, strict fixed-shot NN pilot.

```bash
python -m safe_iad.run_baseline_pilot --config configs/baseline_pilot.json
python plot_pilot.py --results /workspace/reports/baseline_pilot/episodes.json --output /workspace/reports/baseline_pilot/pilot_summary.png
```

Milestone 2: source-only synthetic/normal counterfactual targets and one-step
reference acquisition. Its evaluation uses the completed M1 initial-bank maps.

```bash
python -m safe_iad.build_training_targets --config configs/milestone2.json
python -m safe_iad.run_acquisition_pilot --config configs/milestone2.json
python plot_acquisition_pilot.py --results /workspace/reports/milestone2/evaluation/episodes.json --output /workspace/reports/milestone2/acquisition_summary.png
```

Milestone 3: signed benefit supervision, source-grouped model selection and
paired validation feasibility evaluation, including declared support omissions.

```bash
python -m safe_iad.build_benefit_targets --config configs/milestone3.json
python -m safe_iad.train_benefit --config configs/milestone3.json
python -m safe_iad.run_benefit_pilot --config configs/milestone3.json
python plot_benefit_pilot.py --results /tmp/safe_iad_milestone3/evaluation/episodes.json --output /tmp/safe_iad_milestone3/benefit_summary.png
```

Read `evaluation/gate.json` before advancing. A failed utility, harmful-
intervention or defect-preservation gate means stop advancement under the
predeclared plan. Running this source does not imply the gate passed or that a
full benchmark has been completed. Synthetic supervision is explicitly marked
and does not establish support-adequacy ground truth or deployment reliability.
The recorded M3 gate is negative and additionally rejects the matched
missing-support mechanism check; larger experiments were not run.

The separate strict normal-calibration hybrid pilot is available through:

```bash
python -m safe_iad.run_pipeline --config configs/experiment_plan.yaml --reproduce true
```

Its full reserved-role plan, `configs/experiment_full.yaml`, is a separate,
unexecuted resource-heavy experiment; respect the disk and memory preflight.
Public AD 2 previews cannot satisfy complete private-submission validation.

## Fresh outputs, copied reports and reproduction limits

Copied reports are inspectable evidence of the recorded environment. They are
not portable resume inputs: completion ledgers contain implementation hashes,
absolute input paths and hashes of source data, checkpoint and generated query
files. Restoring only metrics or figures does not restore those inputs. A
completed-run integrity/resume check is also not an independent rerun of every
episode. Never relabel such a check as a full reproduction.

For a fresh M3 run, create a new configuration with separate output, synthetic-
query and feature-cache directories. For example, from `/workspace/tools`:

```bash
python - <<'PY'
import json
from pathlib import Path

config = json.loads(Path('configs/milestone3.json').read_text())
new_root = Path('/workspace/reports/milestone3_fresh')
if new_root.exists():
    raise FileExistsError('Choose a new output directory; preserve existing results.')
config['output'] = str(new_root)
config['feature_cache'] = str(new_root / 'feature_cache')
config['generated_root'] = str(new_root / 'generated_queries')
destination = Path('configs/milestone3_fresh.json')
if destination.exists():
    raise FileExistsError('Preserve the existing config or choose a different name.')
destination.write_text(json.dumps(config, indent=2) + '\n')
PY
python -m safe_iad.build_benefit_targets --config configs/milestone3_fresh.json
python -m safe_iad.train_benefit --config configs/milestone3_fresh.json
python -m safe_iad.run_benefit_pilot --config configs/milestone3_fresh.json
```

For fresh M1/M2 runs, likewise copy their JSON configurations and choose new
`output` paths. Update M2's `baseline_output` to the new M1 output and
`generated_root` to a new directory. For a fresh strict hybrid run, use a new
`--output` directory, and point its role configuration and manifest at the
corresponding restored or newly generated M2 inputs. Changing code, scientific
configuration or data requires renewed validation and new outputs.
