# Register-DINO + PCA hybrid: completed CPU study

The new independent model uses real frozen DINOv2 ViT-L/14 with four registers,
392-pixel cropped inputs, raw mean blocks 4–18, six support augmentations and
three search slots. One original normal image fits each bank; zero extra
target calibration images. The selected global PCA retains 95% variance and
adds its normalized residual with strength 0.5. Local and gated controls were
eligible but did not win. No LLM or backbone fine-tuning is performed.
Parameter selection uses 50 normal and 50 anomalous development images and
their masks from five source categories. Normal-only refers to fitting each
target feature bank; the entire selection procedure is not label-free.

On 100 reserved image IDs across five categories outside current parameter
selection, repeated across two support draws (200 paired cases), baseline
image AUROC is 97.80% and hybrid AUROC is
98.70%. The conditional paired difference interval is
[-0.50, +3.00] percentage points. Full measured
accuracy, localization, false alarms, category results and limitations are in
`reports/report.md`. This is a bounded study; full-paper superiority is not
established. Some categories have historical prototype exposure.

## Run the fixed example model

The included bottle/one-shot/seed17 bank was fixed by convention, not selected
for best performance. Full code, tests and licensed Meta source are included.
Install the pinned runtime, then fetch the separately distributed official
1.22 GB foundation checkpoint:

```bash
cd tools
bash install_safal.sh
source .venv/bin/activate
python prepare_vision_hybrid.py --destination ../assets --source-dir ../vendor/dinov2
python -m safe_iad.vision_hybrid_cli predict --model ../model/model \
  --image /path/to/your/bottle.png --output ../new_prediction \
  --source-dir ../vendor/dinov2 --checkpoint ../assets/dinov2_vitl14_reg4_pretrain.pth
```

The installer creates `tools/.venv`. Predictions use no labels
or masks. They return an image decision and a 256x256 center-ROI anomaly map;
outer borders are unscored. Scores are not probabilities. The baseline-derived
global development-normal cutoff has no target false-alarm guarantee. The
model verifies numerical versions, source and checkpoint SHA256.

All 20 fitted banks, all raw branches, 200 evaluation maps and complete audit
files are available in the separately published complete archive. Use
`tools/download_vision_hybrid_results.py --ref PAYLOAD_COMMIT --extract` with
the immutable commit recorded in the repository release README. Raw dataset
images and foundation checkpoint binaries are excluded from both packages.

See `tools/docs/vision_hybrid.md` for equations, selection rules, exact recipe,
reproduction stages and the provided full-reference benchmark driver. The full
27-category, five-seed, 1/2/4-shot benchmark has not been executed.
