# Dataset-derived model artifact notice

MVTec AD derived feature banks retain the dataset's CC BY-NC-SA 4.0 conditions:
https://www.mvtec.com/company/research/datasets/mvtec-ad
Credit MVTec Software GmbH and Bergmann et al., MVTec AD (CVPR 2019).
The compact bank is derived from MVTec AD bottle and is for noncommercial use.
VisA derived banks in the complete archive retain CC BY 4.0 conditions:
https://github.com/amazon-science/spot-diff
Credit Zou et al., SPot-the-Difference (ECCV 2022), and the VisA creators.
No ownership of original dataset imagery is claimed. Foundation weights and
licensed Meta source retain their own accompanying notices. No inspected
unlicensed VisionAD repository files are redistributed.
