# SAFAL full model v0.5.0

Start with tools/docs/full_model.md. Executable source is under tools/; the GitHub repository stores the same files under framework/. Python 3.12 is required.

```bash
cd tools
bash install_safal.sh
source .venv/bin/activate
python -m safe_iad.safal_cli prepare --destination ../safal_assets
```

Set encoder/dataset paths in the example JSON configs before running them. The prepare command verifies the real frozen DINOv2 weights and pinned source; no random fallback exists. The bundled vendor/dinov2 directory can replace the Git source: its 158-entry pinned manifest is checksum-verified by the portable encoder. The pretrained checkpoint and datasets are separate downloads.

The full pipeline implements normal support/PCA fitting, cosine search, normal image/patch cutoffs, constituent/fixed/max/SAFAL fusion, compatibility/uncertainty diagnostics, separate source-proxy error estimation, evaluation, inference and JSON/NPZ checkpoint loading. Checkpoint arrays avoid pickle. Native image prediction maps and the 256x256 evaluation geometry are distinct.

Two fitted k2/seed5 examples are included at reports/safal_full_model/episodes/mvtec_ad-hazelnut-k2-seed5/model.{json,npz} and visa-pcb2-k2-seed5/model.{json,npz}. Each episode/encoder.json includes runtime_config paths that can be relocated. Preserve semantic encoder settings and verified source/weight checksums. The source-only fitted error estimator is reports/safal_full_model/error_calibrator.json. Model JSON files for other episodes are inspection metadata; their large support arrays are not included.

Read reports/safal_full_model/research_report.md, summary.json, figures/ and verification/. All 159 unit/contract tests passed. Train/evaluate/predict/resume commands ran against real data; all evaluation metrics reproduced and native prediction maps were finite. Portable plain-vendor and fresh Git sources reproduced an actual float32 feature probe exactly. Independent artifact/probe validation is included. Current-instance checks do not prove a fresh dependency installation or full benchmark.

The paired pilot uses eight unique native images, 16 episodes and 320 method records. SAFAL accuracy matched fixed averaging (0.9375) and was below the PCA branch (0.96875); higher accuracy is not established. Support cutoffs use k+4 target normal observations, not strict k-image information. Adequacy and uncertainty are bounded diagnostics. Error probabilities were fitted only on source normal/CutPaste proxy events and are not calibrated native reliability guarantees.

Reports preserve historical M1/M2/M3 and strict-hybrid findings, including the negative M3 gate. Raw datasets, encoder checkpoint binaries, generated training images, feature caches, large episode/probe/map arrays and environment directories are excluded. Historical complete result archives remain separately published in ennayriomar/newpr. Copied completion ledgers contain original absolute input paths; a fresh benchmark must use verified local inputs and a new output directory.

MANIFEST.sha256.json records every bundled file except itself. Read MODEL_ARTIFACT_NOTICE.md and upstream vendor license files before reusing fitted banks or data-derived outputs.
