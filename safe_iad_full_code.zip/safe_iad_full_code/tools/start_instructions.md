Use the existing checkouts under /workspace. Each task is isolated; do not create a Git worktree unless the user explicitly requests one.

The selected /workspace/ennayriomar checkout is a profile README, not the requested research code. Ask for the actual anomaly-localization repository URL before integrating changes; preserve its source and interfaces when it arrives.

Standalone dataset acquisition and verification helpers are in /workspace/tools. Use /workspace/venvs/safe_iad/bin/python and set PYTHONPATH=/workspace/tools for safe_iad commands. PyTorch 2.7.1+cpu is installed; no GPU has been verified. Use at most four verification workers. These commands require no background services.

Check /workspace/reports/dataset_downloads/download_manifest.json and extraction reports for actual retained roots and integrity status. Never use roots ending in .unverified. The acquisition helper keeps outputs staged until their archive SHA-256 is verified. Dataset processes do not survive publication; confirm completion from reports and restart only an incomplete job with explicit preservation of any unverified outputs.

Validate actual datasets using: PYTHONPATH=/workspace/tools /workspace/venvs/safe_iad/bin/python -m safe_iad.verify_dataset --dataset mvtec_ad|visa|mvtec_ad2 --root <verified-root> --output /workspace/reports/dataset_verification --workers 4. Select one dataset name rather than a literal pipe expression. Check the exit status, verification.json, images.jsonl and sample visual artifacts. Native-split checks do not establish experimental validation/calibration isolation; an experiment manifest is still required.

MVTec AD 2 local data intentionally excludes test_private and test_private_mixed to fit storage. Only public masks can be evaluated locally. Official loader and prediction-submission utilities are under /workspace/datasets/official_ad2_tools; no private-test result has been produced.

The DINOv2 checkpoint must load from the official verified HTTPS source with strict state-dict loading; never fall back to random weights. Check the current real_weight_verification.json report. No model pilot should be claimed completed unless its actual results are saved. Continue Milestone 1 before later method or acquisition experiments.

