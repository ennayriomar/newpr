# Safe IAD reports and figures

This ZIP contains all browsable report files, metrics, plots, split and provenance records, calibration records, validation reports, logs, and implementation source snapshots. Start with `results/README.md` or `results/hybrid_framework_report.md`.

For all raw anomaly maps, prediction TIFFs, and every original result file, use the complete archive and downloader at https://github.com/ennayriomar/newpr/tree/main/results_archive . This reports ZIP excludes `.npz`, `.tiff`, and `.pyc` files, which are preserved in that full archive.

The current result is a five-category pilot; the full 20-category and private AD 2 evaluations have not been run. Absolute `/workspace` paths describe the original cloud execution environment.
