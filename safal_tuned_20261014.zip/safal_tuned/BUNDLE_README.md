# Development-selected SAFAL — 14 October 2026

Read reports/report.md and reports/summary.json for the measured outcome,
including defect losses, conditional paired intervals and limitations.
The chosen parameters were selected with native development labels, locked,
then compared on100 prelocked verification images within five previously
development-exposed categories. This is not a pristine-category final test,
full benchmark, probability-calibration result, SOTA claim or production proof.

The framework is under tools/. Five category-specific fitted normal banks
are in models/, chosen by fixed k4/seed17 rather than model performance.
Every model uses four support images and four extra normal calibration images;
it is not a strict four-image information budget. The15 primary fitted banks,
300 metric map files,15 replay probes, development raw scores, locks, full grid
and audits are preserved in the separately published complete result archive.
That archive also preserves superseded attempt banks and logs under attempts/;
they are historical outputs, not additional primary evaluation runs. Exact
total and superseded model-bank counts are recorded in its manifest. No old
probability/error head is attached to the changed decision rule.

## Portable prediction

Use Python3.12 and the pinned CPU setup. The bundled official DINOv2 source
includes its trusted source_manifest.sha256.json. Prepare the separately
verified pretrained weights once (the command also prepares another clean
source checkout); existing verified assets can be reused instead:

```bash
cd tools
bash install_safal.sh
source .venv/bin/activate
python -m safe_iad.safal_features prepare --destination ../safal_assets
python -m safe_iad.safal_tuned_predict --model ../models/mvtec_ad-hazelnut-k4-seed17/model --image /absolute/path/YOUR_IMAGE.png --output ../new_prediction --source-dir ../vendor/dinov2 --source-manifest ../vendor/dinov2/source_manifest.sha256.json --checkpoint ../safal_assets/dinov2_vitb14_pretrain.pth --cache-root ../feature_cache --threads 3
```

Choose the bank matching the image's category. Runtime paths in archived
metadata describe the original cloud machine; explicit path overrides make
inference portable while retaining encoder source/weight hashes, resolution,
layers and preprocessing. Native float32 maps differ from the declared256×256
evaluation maps. A/U and weights are empirical diagnostics, not probabilities.

## Reproduction and archived inputs

Inference needs only this compact bank/code bundle plus the frozen weights.
Reproducing parameter search additionally needs actual MVTec AD/VisA datasets
and the prior fitted-run manifest/predictions. That prior historical complete
result archive is approximately3GB and was published separately in
ennayriomar/newpr. Update previous_run/development_manifest, data roots,
verification-lock/exposure paths and encoder/cache paths in
tools/configs/safal_tuning_20261014.json to local copies; use a new output.
Do not treat copied absolute-path completion ledgers as a verified local resume.
Exact search/verification commands and selection rules are documented in
tools/docs/parameter_tuning.md. Legacy sources/checkpoints remain separate.

Raw datasets, pretrained weights, external feature caches and large prediction
arrays are omitted from this compact ZIP. The complete new-run archive includes
all run-derived arrays/models/reports (and preserved attempt logs), while raw
dataset images and encoder weights remain separate. MANIFEST.sha256.json
records every bundled file except itself. Read MODEL_ARTIFACT_NOTICE.md and
vendor licenses before reusing these data-derived banks.
